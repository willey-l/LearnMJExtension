//
//  MJPropertyType.m
//  字典转模型(一)
//
//  Created by 叶 on 15/9/10.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import "MJPropertyType.h"

@implementation MJPropertyType

+ (instancetype)propertyTypeWithAttributeString:(NSString *)string{
    return [[MJPropertyType alloc] initWithTypeString:string];
}

- (instancetype)initWithTypeString:(NSString *)string
{
    if (self = [super init])
    {
        NSUInteger loc = 1;
        NSUInteger len = [string rangeOfString:@","].location - loc;
        NSString *type = [string substringWithRange:NSMakeRange(loc, len)];
    
        NSLog(@"%@",type);
    }
    return self;
}

@end
